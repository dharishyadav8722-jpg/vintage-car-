
const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = 5000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "..")));

// Create a permanent database file
const db = new Database(path.join(__dirname, "vintage-wheels.db"));

db.exec(`
  CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    email TEXT NOT NULL,
    car_name TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    total_price REAL NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

app.get("/api", (req, res) => {
  res.json({ message: "Vintage Wheels backend is working!" });
});

// Save a booking permanently
app.post("/api/bookings", (req, res) => {
  const {
    customer_name,
    email,
    car_name,
    start_date,
    end_date,
    total_price
  } = req.body;

  if (
    !customer_name ||
    !email ||
    !car_name ||
    !start_date ||
    !end_date ||
    !Number.isFinite(Number(total_price)) ||
    Number(total_price) < 0
  ) {
    return res.status(400).json({
      message: "Please provide all booking details."
    });
  }

  const result = db.prepare(`
    INSERT INTO bookings
      (customer_name, email, car_name, start_date, end_date, total_price)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    customer_name,
    email,
    car_name,
    start_date,
    end_date,
    Number(total_price)
  );

  res.status(201).json({
    message: "Booking saved permanently!",
    id: result.lastInsertRowid
  });
});

// View saved bookings
app.get("/api/bookings", (req, res) => {
  const bookings = db.prepare(
    "SELECT * FROM bookings ORDER BY id DESC"
  ).all();

  res.json(bookings);
});

app.listen(PORT, () => {
  console.log(`Vintage Wheels server running at http://localhost:${PORT}`);
});
