const menu = document.getElementById('menu');
const links = document.getElementById('links');

menu.addEventListener('click', () => links.classList.toggle('open'));
links.querySelectorAll('a').forEach(a =>
  a.addEventListener('click', () => links.classList.remove('open'))
);

document.querySelectorAll('.filter').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const filter = btn.dataset.filter;
    document.querySelectorAll('.car').forEach(card => {
      card.hidden = filter !== 'all' && !card.dataset.category.split(' ').includes(filter);
    });
  });
});

document.querySelectorAll('.heart').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.toggle('saved');
    btn.textContent = btn.classList.contains('saved') ? '♥' : '♡';
  });
});

const carSelect = document.getElementById('carSelect');
const days = document.getElementById('days');
const estimate = document.getElementById('estimate');
const date = document.getElementById('date');

function updateEstimate() {
  const option = carSelect.options[carSelect.selectedIndex];
  const price = Number(option.dataset.price || 0);

  estimate.textContent = price
    ? new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
      }).format(price * Number(days.value))
    : 'Select a car';
}

carSelect.addEventListener('change', updateEstimate);
days.addEventListener('change', updateEstimate);

document.querySelectorAll('.book-car').forEach(btn => {
  btn.addEventListener('click', () => {
    carSelect.value = btn.dataset.car;
    updateEstimate();
    document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
  });
});

date.min = new Date().toISOString().split('T')[0];
document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('bookingForm').addEventListener('submit', async e => {
  e.preventDefault();

  const form = e.currentTarget;
  const data = new FormData(form);
  const message = document.getElementById('formMessage');
  const selectedOption = carSelect.options[carSelect.selectedIndex];
  const totalPrice = Number(selectedOption.dataset.price || 0) * Number(days.value);

  message.textContent = 'Sending your booking request...';

  try {
    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customer_name: data.get('name'),
        email: data.get('email'),
        car_name: data.get('car'),
        start_date: data.get('date'),
        end_date: data.get('date'),
        total_price: totalPrice
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.message || 'Could not save your booking.');
    }

    message.textContent = `Thank you, ${data.get('name')}! Your booking request was saved successfully. Booking number: ${result.id}. Estimated total: ${estimate.textContent}.`;
    form.reset();
    updateEstimate();
  } catch (error) {
    message.textContent = `Booking could not be saved: ${error.message}. Please check that the server is running and try again.`;
  }
});

updateEstimate();